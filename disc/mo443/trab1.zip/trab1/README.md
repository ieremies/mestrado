# Trabalho 1 - Processamento digital de imagem
Ieremies V. F. Romero (217938)

## Relatório
O relatório pode ser encontrado na pasta "build", tanto no formato .pdf como .html, bem como os arquivos fontes (.org e .tex).

## Código
No relatório é melhor descrito, mas os dois únicos arquivos são `funcs.py` com as funções que resolvem as questões e o arquivo `script.py` que executa tais funções, bem como leitura e escrita.

Utilize `python script.py` para reproduzir os resultados. As imagens serão colocadas novamente na pasta "out".
